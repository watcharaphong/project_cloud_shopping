<?php
setcookie('name','',time()-(86400 * 30), "/");
setcookie('user','',time()-(86400 * 30), "/");

echo"<script>
window.location='index.php';</script>";
 ?>
 ?>
